/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
    import Model.*;
    import View.viewAdmin_EditKeahlianPengajar;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.sql.ResultSet;
import javax.swing.DefaultListModel;

/**
 *
 * @author Hilmi
 */
public class HandlerAdmin_EditKeahlianPengajar implements ActionListener{
    private viewAdmin_EditKeahlianPengajar editKeahlian;
    
    public HandlerAdmin_EditKeahlianPengajar(){
        editKeahlian = new viewAdmin_EditKeahlianPengajar();
        editKeahlian.setVisible(true);
        editKeahlian.addActionListener(this);
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(editKeahlian.getAddKeahlian())){
            Database db = new Database();
            cek x = new cek();
            Pengajar j = x.cariPengjar_idPengajar(editKeahlian.getTampIdPengajar().getText());
            String s = x.splitText(editKeahlian.getTableNoSelectetMatkulJurusan().getSelectedValue());
            Matkul m = x.cariMatkul_idMatkul(s);
            if (x.cekidMengajar(j.getIdPengajar()+"-"+m.getIdMatkul())==false) {
                Mengajar c = new Mengajar(j,m);
                db.tambahMengajar(c);
                db.editPengajar(j, j.getJumlahKeahlian()+1);
            }
            showlistSelectedMatkul();
            showlistNotSelectedMatkul();
        } else if (source.equals(editKeahlian.getRemoveKeahlian())){
            Database db = new Database();
            cek x = new cek();
            Pengajar j = x.cariPengjar_idPengajar(editKeahlian.getTampIdPengajar().getText());
            String s = x.splitText(editKeahlian.getTableSelectetMatkulJurusan().getSelectedValue());
            Matkul m = x.cariMatkul_idMatkul(s);
            if (x.cekidMengajar(j.getIdPengajar()+"-"+m.getIdMatkul())==true) {
                Mengajar c = new Mengajar(j,m);
                db.hapusMengajar(c);
                db.editPengajar(j, j.getJumlahKeahlian()-1);
            }
            showlistSelectedMatkul();
            showlistNotSelectedMatkul();
        } else if (source.equals(editKeahlian.getDone())){
            Database db = new Database();
            cek x = new cek();
            Pengajar j = x.cariPengjar_idPengajar(editKeahlian.getTampIdPengajar().getText());
            if (j.getJumlahKeahlian()==0) {
                db.hapusPengajar(j);
            }
            editKeahlian.dispose();
        }
        
    }
    
    public void setAdmin_EditKeahlianPengajarWindow(Pelajar x){
        cek c = new cek();
        Pengajar p = c.cariPengjar_idPengajar(x.getNim()+"-P");
        editKeahlian.getTampIdPengajar().setText(p.getIdPengajar());
        editKeahlian.getTampnamaPengajar().setText(x.getNama());
        Jurusan j = c.cariJurusan_idJurusan(x.getIdjurusan());
        editKeahlian.getTampJurusan().setText(j.getNamaJurusan());
        showlistSelectedMatkul();
        showlistNotSelectedMatkul();
    }
    
    public void showlistNotSelectedMatkul(){
        DefaultListModel model = new DefaultListModel();
        model.removeAllElements();
        int i = 0;
        cek x = new cek();
        if (!"...".equals(editKeahlian.getTampIdPengajar().getText())) {
            Pengajar pg = x.cariPengjar_idPengajar(editKeahlian.getTampIdPengajar().getText());
            Jurusan h = x.cariJurusan_namaJurusan(editKeahlian.getTampJurusan().getText());
            try{
                Database db = new Database();
                ResultSet rs = db.getData("select * from curriculum where idJurusan ='"+h.getIdJurusan()+"' and idMatkul <> all (select idMatkul from mengajar where idPengajar='"+pg.getIdPengajar()+"')");
                while(rs.next()){
                    Matkul y = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    model.addElement(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                }
                editKeahlian.getTableNoSelectetMatkulJurusan().setModel(model);
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public void showlistSelectedMatkul(){
        DefaultListModel model = new DefaultListModel();
        model.removeAllElements();
        int i = 0;
        cek x = new cek();
        if (!"...".equals(editKeahlian.getTampIdPengajar().getText())) {
            Pengajar pg = x.cariPengjar_idPengajar(editKeahlian.getTampIdPengajar().getText());
            Jurusan h = x.cariJurusan_namaJurusan(editKeahlian.getTampJurusan().getText());
            try{
                Database db = new Database();
                ResultSet rs = db.getData("select * from mengajar where idPengajar='"+pg.getIdPengajar()+"';");
                while(rs.next()){
                    Matkul y = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    model.addElement(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                }
                editKeahlian.getTableSelectetMatkulJurusan().setModel(model);
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
}
