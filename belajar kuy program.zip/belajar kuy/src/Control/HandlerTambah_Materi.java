/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.*;
import View.viewTambah_Materi;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author ACER
 */
public class HandlerTambah_Materi implements ActionListener {
    private viewTambah_Materi materi;

    public HandlerTambah_Materi() {
        materi = new viewTambah_Materi();
        materi.setVisible(true);
        materi.addActionListener(this);
    }
    @Override
     public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(materi.getTambahMateri())){
            Database db = new Database();
            cek c = new cek();
            String x = materi.getIsiMateri().getText();
            String y = materi.getIsiSoal().getText();
            withMentor h = c.cariKelas_idKelasWithmentor(materi.getTampIdKelas1().getText());
            db.editKelasMateri(h, x, y);
            javax.swing.JOptionPane.showMessageDialog(null, "Materi Sudah Ditambah");
        }else if (source.equals(materi.getKembaliPengajar())){
            materi.dispose();
        }
        
     }
     
     public void showUser_DetailKelasJoinWindow(withMentor w, String idPengajar){
        //Database db = new Database();
        //cek c = new cek();
        materi.getTampidPengajar().setText(idPengajar);
        materi.getTampIdKelas1().setText(w.getIdKelas());
        materi.getTampNamaKelas1().setText(w.getNamaKelas());
        materi.getTampTanggal1().setText(w.getTanggal());
        materi.getTampJam1().setText(w.getJam());
        materi.getTampLokasi1().setText(w.getLokasi());
        materi.getTampKapasitas1().setText(w.getJumAnggota()+"/"+w.getMaxAnggota());
        materi.getTampMatkul1().setText(w.getCurriculum().getMatkul().getIdMatkul()+"  "+w.getCurriculum().getMatkul().getNamaMatkul());
        materi.getDeskripsiKelas1().setText(w.getDeskripsiKelas());
        materi.getIsiMateri().setText(w.getMateri());
        materi.getIsiSoal().setText(w.getSoal());
    }
}
