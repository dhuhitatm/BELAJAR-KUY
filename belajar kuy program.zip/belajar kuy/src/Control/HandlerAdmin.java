/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
    import Model.*;
    import View.viewAdmin;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.sql.ResultSet;
    import javax.swing.DefaultListModel;
    import javax.swing.UIManager;
    import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Hilmi
 */
public class HandlerAdmin implements ActionListener{
    
    private viewAdmin admin;
    
    public HandlerAdmin(){
        admin = new viewAdmin();
        admin.setVisible(true);
        admin.addActionListener(this);
        showTableJurusan();
        showComboJurusan();
        showTablePelajar();
        showTablePengajar();
        showTableMatkul();
        showlistNotSelectedMatkul();
        showlistSelectedMatkul();
        showcomboSelectedMatkul();
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source.equals(admin.getTambahPelajar())){
            if (admin.getNimTbhPelajar().getText().isEmpty()==false&&admin.getNamaTbhPelajar().getText().isEmpty()==false&&admin.getUsernameTbhPelajar().getText().isEmpty()==false&&admin.getPasswordTbhPelajar().getText().isEmpty()==false) {
                Database db = new Database();
                Pelajar p = new Pelajar();
                cek x = new cek();
                p.setNim(admin.getNimTbhPelajar().getText());
                p.setNama(admin.getNamaTbhPelajar().getText());        
                Jurusan h = x.cariJurusan_namaJurusan((String) admin.getJurusanTbhPelajar().getSelectedItem());
                p.setIdjurusan(h.getIdJurusan());       
                String d = (String) admin.getAngkatanTbhPelajar().getSelectedItem();
                int dx=0;
                if (d=="2015") {
                    p.setAngkatan(2015);
                } else if (d=="2016"){
                    p.setAngkatan(2016);
                } else if (d=="2017") {
                    p.setAngkatan(2017);
                } else if (d=="2018"){
                    p.setAngkatan(2018);
                }        
                p.setUsername(admin.getUsernameTbhPelajar().getText());
                p.setPassword(admin.getPasswordTbhPelajar().getText());
                p.setJumJoin(0);
                if (x.cekNimPelajar(p.getNim())==false) {
                    if (x.cekUsernamePelajar(p.getUsername())==false) {
                        db.tambahPelajar(p);
                        javax.swing.JOptionPane.showMessageDialog(null, "Tambah Pelajar Berhasil"); 
                    }else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Pelajar Gagal. [USERNAME SUDAH ADA]");   
                    }
                }else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Pelajar Gagal. [NIM SUDAH ADA]");
                }
                admin.getNimTbhPelajar().setText("");
                admin.getNamaTbhPelajar().setText("");
                admin.getUsernameTbhPelajar().setText("");
                admin.getPasswordTbhPelajar().setText("");
                showTablePelajar();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data Yang Masih Kosong!");
            }
        } else if(source.equals(admin.getCariHpsPelajar())){
            if (admin.getNimHpsPelajar().getText().isEmpty()==false) {
                String a = admin.getNimHpsPelajar().getText();
                cek x =new cek();
                Pelajar h = x.cariPelajar_nim(a);
                if (h!=null) {
                    Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                    if (x.cekNimPengajar(a)==true) {
                        javax.swing.JOptionPane.showMessageDialog(null, h.getNama()+" Juga Akan Terhapus Dari Daftar Pengajar");
                    }
                    admin.getNamaHpsPelajar().setText(h.getNama());
                    admin.getJurusanHpsPelajar().setText(k.getNamaJurusan()+" "+h.getAngkatan());
                    admin.getTampHpsNIMpelajar().setText(a);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "NIM Tidak Ditemukan");
                }
                admin.getNimHpsPelajar().setText("");
            }
        } else if (source.equals(admin.getHapusPelajar())){
            if (!"...".equals(admin.getTampHpsNIMpelajar().getText())) {
                Database db = new Database();
                cek x = new cek();
                Pelajar h = x.cariPelajar_nim(admin.getTampHpsNIMpelajar().getText());
                db.hapusPelajar(h);
                javax.swing.JOptionPane.showMessageDialog(null, "Hapus Pelajar Berhasil");
                admin.getTampHpsNIMpelajar().setText("...");
                admin.getNamaHpsPelajar().setText("");
                admin.getJurusanHpsPelajar().setText("");
                showTablePelajar();
                showTablePengajar();   
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getHapusPelajar())){
            if (!"...".equals(admin.getTampHpsNIMpelajar().getText())) {
                if (admin.getNamaHpsPelajar().getText().isEmpty()==false) {
                    Database db = new Database();
                    cek x = new cek();
                    Pelajar h = x.cariPelajar_nim(admin.getTampHpsNIMpelajar().getText());
                    String a = admin.getNamaHpsPelajar().getText();
                    db.editPelajar(h,a);
                    javax.swing.JOptionPane.showMessageDialog(null, "Edit Pelajar Berhasil");
                    admin.getTampHpsNIMpelajar().setText("...");
                    admin.getNamaHpsPelajar().setText("");
                    admin.getJurusanHpsPelajar().setText("");
                    showTablePelajar();
                    showTablePengajar();
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data Yang Masih Kosong!");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getCariTbhPengajar())){
            if (admin.getNimTbhPengajar().getText().isEmpty()==false){
                String a = admin.getNimTbhPengajar().getText();
                cek x =new cek();
                Pelajar h = x.cariPelajar_nim(a);
                Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                if (h!=null) {
                    if (x.cekNimPengajar(a)==false) {
                        admin.getNamaTbhPengajar().setText(h.getNama());
                        admin.getJurusanTbhPengajar().setText(k.getNamaJurusan()+" "+h.getAngkatan());
                        admin.getTampTbhNIM().setText(a);
                    } else {
                        javax.swing.JOptionPane.showMessageDialog(null, "Pengajar Sudah Terdaftar");
                    }
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "NIM Tidak Ditemukan");
                }
                admin.getNimTbhPengajar().setText("");
                showcomboSelectedMatkul();
            }
        } else if (source.equals(admin.getTambahPengajar())){
            if (!"...".equals(admin.getTampTbhNIM().getText())) {
                Database db = new Database();
                cek x = new cek();
                Pelajar h = x.cariPelajar_nim(admin.getTampTbhNIM().getText());
                Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                String s = x.splitText((String) admin.getKeahlianTbhPengajar().getSelectedItem());
                Matkul m = x.cariMatkul_idMatkul(s);
                h = new Pengajar (h.getNama(),h.getNim(),h.getIdjurusan(),h.getAngkatan(),h.getUsername(),h.getPassword(),h.getJumJoin());
                Pengajar y = (Pengajar) h;
                y.setJumlahKeahlian(y.getJumlahKeahlian()+1);
                db.tambahPengajar(y);
                Mengajar mjr = new Mengajar(y,m);
                db.tambahMengajar(mjr);
                javax.swing.JOptionPane.showMessageDialog(null, "Tambah Pengajar Berhasil");
                admin.getTampTbhNIM().setText("...");
                admin.getNamaTbhPengajar().setText("");
                admin.getJurusanTbhPengajar().setText("");
                admin.getKeahlianTbhPengajar().removeAllItems();
                showTablePengajar();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getCariHpsPengajar())){
            if (admin.getNimHpsPengajar().getText().isEmpty()==false) {
                String a = admin.getNimHpsPengajar().getText();
                cek x =new cek();
                Pelajar h = x.cariPelajar_nim(a);
                Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                if (h!=null) {
                    if (x.cekNimPengajar(a)==true) {
                        admin.getNamaHpsPengajar().setText(h.getNama());
                        admin.getJurusanHpsPengajar().setText(k.getNamaJurusan()+" "+h.getAngkatan());
                        admin.getTampHpsNIMpengajar().setText(a);
                    } else {
                        javax.swing.JOptionPane.showMessageDialog(null, "Bukan Pengajar");
                    }
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "NIM Tidak Ditemukan");
                }
                admin.getNimHpsPengajar().setText("");
            }
        } else if (source.equals(admin.getHapusPengajar())){
            if (!"...".equals(admin.getTampHpsNIMpengajar().getText())) {
                Database db = new Database();
                cek x = new cek();
                Pelajar h = x.cariPelajar_nim(admin.getTampHpsNIMpengajar().getText());
                Jurusan k = x.cariJurusan_idJurusan(h.getIdjurusan());
                h = new Pengajar (h.getNama(),h.getNim(),k.getIdJurusan(),h.getAngkatan(),h.getUsername(),h.getPassword(), h.getJumJoin());
                Pengajar y = (Pengajar) h;
                db.hapusPengajar(y);
                javax.swing.JOptionPane.showMessageDialog(null, "Hapus Pengajar Berhasil");
                admin.getTampHpsNIMpengajar().setText("...");
                admin.getNamaHpsPengajar().setText("");
                admin.getJurusanHpsPengajar().setText("");
                showTablePengajar();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getEditkeahlianPengajar())){
            if (!"...".equals(admin.getTampHpsNIMpengajar().getText())) {
                HandlerAdmin_EditKeahlianPengajar f = new HandlerAdmin_EditKeahlianPengajar();
                cek x = new cek();
                Pelajar p = x.cariPelajar_nim(admin.getTampHpsNIMpengajar().getText());
                f.setAdmin_EditKeahlianPengajarWindow(p);
                admin.getTampHpsNIMpengajar().setText("...");
                admin.getNamaHpsPengajar().setText("");
                admin.getJurusanHpsPengajar().setText("");
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getTambahMatkul())){
            if (admin.getIdmatkulTbhJurusan().getText().isEmpty()==false&&admin.getNamamatkulTbhJurusan().getText().isEmpty()==false) {
                Matkul a = new Matkul();
                a.setIdMatkul(admin.getIdmatkulTbhJurusan().getText());
                a.setNamaMatkul(admin.getNamamatkulTbhJurusan().getText());
                cek x = new cek();
                if (x.cekidMatkul(a.getIdMatkul())==false) {
                    Database db = new Database();
                    db.tambahMatkul(a);
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Matkul Berhasil");

                } else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Matkul Gagal. [DATA SUDAH ADA]!");
                }
                admin.getIdmatkulTbhJurusan().setText("");
                admin.getNamamatkulTbhJurusan().setText("");
                showTableMatkul();
                showlistNotSelectedMatkul();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data Yang Masih Kosong!");
            }
        } else if (source.equals(admin.getCariEdtMatkul())){
            if (admin.getIdjurusanEdtMatkul().getText().isEmpty()==false) {
                String a = admin.getIdjurusanEdtMatkul().getText();
                cek x =new cek();
                Matkul h = x.cariMatkul_idMatkul(a);
                if (h!=null) {
                    admin.getNamamatkulEdtMatkul().setText(h.getNamaMatkul());
                    admin.getTampIdMatkul().setText(a);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "idMatkul Tidak Ditemukan");
                }
                admin.getIdjurusanEdtMatkul().setText("");
            } 
        }else if (source.equals(admin.getHapusMatkul())){
            if (!"...".equals(admin.getTampIdMatkul().getText())) {
                Database db = new Database();
                cek x = new cek();
                Matkul h = x.cariMatkul_idMatkul(admin.getTampIdMatkul().getText());
                Mengajar m = new Mengajar();
                db.hapusMengajardanPengajar(h.getIdMatkul());

                db.hapusMatkul(h);
                javax.swing.JOptionPane.showMessageDialog(null, "Hapus Matkul Berhasil");

                admin.getTampIdMatkul().setText("...");
                admin.getNamamatkulEdtMatkul().setText("");
                showTableMatkul();
                showlistNotSelectedMatkul();
                showlistSelectedMatkul();
            }else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        }else if (source.equals(admin.getEditMatkul())){
            if (!"...".equals(admin.getTampIdMatkul().getText())) {
                if (admin.getNamamatkulEdtMatkul().getText().isEmpty()==false) {
                    Database db = new Database();
                    cek x = new cek();
                    Matkul h = x.cariMatkul_idMatkul(admin.getTampIdMatkul().getText());
                    String a = admin.getNamamatkulEdtMatkul().getText();
                    db.editMatkul(h,a);
                    javax.swing.JOptionPane.showMessageDialog(null, "Edit Matkul Berhasil");
                    admin.getTampIdMatkul().setText("...");
                    admin.getNamamatkulEdtMatkul().setText("");
                    showTableMatkul();
                    showlistNotSelectedMatkul();
                    showlistSelectedMatkul();
                }else {
                    javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data Yang Masih Kosong!");
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getTambahJurusan())){
            if (admin.getIdjurusanTbhJurusan().getText().isEmpty()==false&&admin.getNamajurusanTbhJurusan().getText().isEmpty()==false) {
                Jurusan a = new Jurusan();
                a.setIdJurusan(admin.getIdjurusanTbhJurusan().getText());
                a.setNamaJurusan(admin.getNamajurusanTbhJurusan().getText());
                Database db = new Database();
                cek x = new cek();
                if (x.cekidJurusan(a.getIdJurusan())==false) {
                    db.tambahJurusan(a);
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Jurusan Berhasil");

                } else{
                    javax.swing.JOptionPane.showMessageDialog(null, "Tambah Jurusan Gagal. [DATA SUDAH ADA]!");
                }
                admin.getIdjurusanTbhJurusan().setText("");
                admin.getNamajurusanTbhJurusan().setText("");
                showTableJurusan();
                showComboJurusan();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Isi Data Yang Masih Kosong!");
            }
        } else if (source.equals(admin.getCariEdtJurusan())){
            if (admin.getIdjurusanEdtJurusan().getText().isEmpty()==false) {
                String a = admin.getIdjurusanEdtJurusan().getText();
                cek x =new cek();
                Jurusan h = x.cariJurusan_idJurusan(a);
                if (h!=null) {
                    admin.getNamajurusanEdtJurusan().setText(h.getNamaJurusan());
                    admin.getTampIdJurusan().setText(a);
                } else {
                    javax.swing.JOptionPane.showMessageDialog(null, "idJurusan Tidak Ditemukan");
                }
                admin.getIdjurusanEdtJurusan().setText("");
            }
        } else if (source.equals(admin.getHapusJurusan())){
            if (!"...".equals(admin.getTampIdJurusan().getText())) {
                Database db = new Database();
                cek x = new cek();
                Jurusan h = x.cariJurusan_idJurusan(admin.getTampIdJurusan().getText());
                db.hapusJurusan(h);
                javax.swing.JOptionPane.showMessageDialog(null, "Hapus Jurusan Berhasil");
                admin.getTampIdJurusan().setText("...");
                admin.getNamajurusanEdtJurusan().setText("");
                showTableJurusan();
                showTablePelajar();
                showTablePengajar();
                showComboJurusan();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getEditJurusan())){
            if (!"...".equals(admin.getTampIdJurusan().getText())) {
                Database db = new Database();
                cek x = new cek();
                Jurusan h = x.cariJurusan_idJurusan(admin.getTampIdJurusan().getText());
                String a = admin.getNamajurusanEdtJurusan().getText();
                db.editJurusan(h,a);
                javax.swing.JOptionPane.showMessageDialog(null, "Edit Jurusan Berhasil");
                admin.getTampIdJurusan().setText("...");
                admin.getNamajurusanEdtJurusan().setText("");
                showTableJurusan();
                showTablePelajar();
                showTablePengajar();
                showComboJurusan();
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Silahkan Cari Data Terlebih Dahulu!");
            }
        } else if (source.equals(admin.getJurusanEdtCurriculum())){
            admin.getTampJurusanEdtCurriculum().setText((String) admin.getJurusanEdtCurriculum().getSelectedItem());
            showlistSelectedMatkul();
            showlistNotSelectedMatkul();
        } else if (source.equals(admin.getAddCurriculum())){
            Database db= new Database();
            cek x = new cek();
            Jurusan j = x.cariJurusan_namaJurusan((String) admin.getJurusanEdtCurriculum().getSelectedItem());
            String s = x.splitText(admin.getListNotSelectedMatkul().getSelectedValue());
            Matkul m = x.cariMatkul_idMatkul(s);
            if (x.cekidCurriculum(j.getIdJurusan()+"-"+m.getIdMatkul())==false) {
                Curriculum c = new Curriculum(m,j);
                db.tambahCurriculum(c);
            }
            showlistNotSelectedMatkul();
            showlistSelectedMatkul();
            showcomboSelectedMatkul();
        } else if (source.equals(admin.getDeleteCurriculum())){
            Database db = new Database();
            cek x = new cek();
            Jurusan j = x.cariJurusan_namaJurusan((String) admin.getJurusanEdtCurriculum().getSelectedItem());
            String s = x.splitText(admin.getListselectedMatkul().getSelectedValue());
            Matkul m = x.cariMatkul_idMatkul(s);
            if (x.cekidCurriculum(j.getIdJurusan()+"-"+m.getIdMatkul())==true) {
                Curriculum c = new Curriculum(m,j);       
                Mengajar h = new Mengajar();
                db.hapusMengajardanPengajar(m.getIdMatkul());
                db.hapusCurriculum(j, m);

            }
            showlistNotSelectedMatkul();
            showlistSelectedMatkul();
            showcomboSelectedMatkul();
            showTablePengajar();
        } else if (source.equals(admin.getRefresh_Pelajar())){
            showTablePelajar();
        } else if (source.equals(admin.getRefresh_Pengajar())){
            showTablePengajar();
        } else if (source.equals(admin.getRefresh_Matkul())){
            showTableMatkul();
        } else if (source.equals(admin.getRefresh_Jurusan())){
            showTableJurusan();
        }else if (source.equals(admin.getGoToUserLogIn())){
            HandlerUser_LogIn f = new HandlerUser_LogIn();
            admin.dispose();
        }
    }
    

    //Tampil Table, Combo dan List untuk Jframe viewAdmin
    
    public void setAdminWindow(String x){
        admin.getTampAdminname().setText(x);
    }
    
    public void showComboJurusan(){
        admin.getJurusanTbhPelajar().removeAllItems();
        admin.getJurusanEdtCurriculum().removeAllItems();
        cek x = new cek();
        try{
            Database db = new Database();
            ResultSet rs = db.getData("SELECT * FROM table_jurusan;");
            while(rs.next()){
                admin.getJurusanTbhPelajar().addItem(rs.getString("namaJurusan"));
                admin.getJurusanEdtCurriculum().addItem(rs.getString("namaJurusan"));
            }
            rs.close();
        }catch (Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
   
    public void showTablePelajar(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        
        try{
            cek x = new cek();
            rs = db.getData("select nim,nama,idjurusan,angkatan,username from table_pelajar;");
            DefaultTableModel model = (DefaultTableModel) admin.getTablepelajar().getModel();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                admin.getTablepelajar().setValueAt(rs.getString("nim"), i, 0);
                admin.getTablepelajar().setValueAt(rs.getString("nama"), i, 1);
                Jurusan k = x.cariJurusan_idJurusan(rs.getString("idjurusan"));
                admin.getTablepelajar().setValueAt(k.getNamaJurusan()+" "+rs.getInt("angkatan"), i, 2);
                admin.getTablepelajar().setValueAt(rs.getString("username"), i, 3);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showTablePengajar(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        try{
            //rs = db.getData("select nim,nama,idjurusan,angkatan,username from table_pelajar join table_pengajar using (nim);");
            rs = db.getData("select * from table_pelajar join table_pengajar using(nim) join mengajar using(idPengajar)");
            DefaultTableModel model = (DefaultTableModel) admin.getTablepengajar().getModel();
            cek x = new cek();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                admin.getTablepengajar().setValueAt(rs.getString("idPengajar"), i, 0);
                admin.getTablepengajar().setValueAt(rs.getString("nama"), i, 1);
                Jurusan k = x.cariJurusan_idJurusan(rs.getString("idjurusan"));
                admin.getTablepengajar().setValueAt(k.getNamaJurusan()+" "+rs.getInt("angkatan"), i, 2);
                admin.getTablepengajar().setValueAt(rs.getString("username"), i, 3);
                Matkul m = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                admin.getTablepengajar().setValueAt(m.getIdMatkul()+"   "+m.getNamaMatkul(), i, 4);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showTableJurusan(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from table_jurusan;");
            DefaultTableModel model = (DefaultTableModel) admin.getTablejurusan().getModel();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                admin.getTablejurusan().setValueAt(rs.getString("idJurusan"), i, 0);
                admin.getTablejurusan().setValueAt(rs.getString("namaJurusan"), i, 1);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showTableMatkul(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        try{
            rs = db.getData("select * from table_matakuliah;");
            DefaultTableModel model = (DefaultTableModel) admin.getTableMatkul().getModel();
            model.setRowCount(0);
            while (rs.next()){
                model.setRowCount(i+1);
                admin.getTableMatkul().setValueAt(rs.getString("idMatkul"), i, 0);
                admin.getTableMatkul().setValueAt(rs.getString("namaMatkul"), i, 1);
                i=i+1;
            }
            rs.close();
        } catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    public void showlistNotSelectedMatkul(){
        Database db = new Database();
        int i = 0;
        ResultSet rs = null;
        cek x = new cek();
        if ((String) admin.getJurusanEdtCurriculum().getSelectedItem()!=null) {
            Jurusan h = x.cariJurusan_namaJurusan((String) admin.getJurusanEdtCurriculum().getSelectedItem());
            try{
                rs = db.getData("select * from table_matakuliah where idMatkul <> ALL (Select idMatkul from curriculum where idJurusan = '"+h.getIdJurusan()+"');");
                DefaultListModel model = new DefaultListModel();
                model.removeAllElements();
                while(rs.next()){
                    model.addElement(rs.getString("idMatkul")+"   "+rs.getString("namaMatkul"));
                }
                admin.getListNotSelectedMatkul().setModel(model);
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public void showlistSelectedMatkul(){
        DefaultListModel model = new DefaultListModel();
        model.removeAllElements();
        int i = 0;
        cek x = new cek();
        if ((String) admin.getJurusanEdtCurriculum().getSelectedItem()!=null) {
            Jurusan h = x.cariJurusan_namaJurusan((String) admin.getJurusanEdtCurriculum().getSelectedItem());
            try{
                Database db = new Database();
                ResultSet rs = db.getData("select * from curriculum where idJurusan='"+h.getIdJurusan()+"';");
                while(rs.next()){
                    Matkul y = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    model.addElement(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                }
                admin.getListselectedMatkul().setModel(model);
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public void showcomboSelectedMatkul(){
        admin.getKeahlianTbhPengajar().removeAllItems();
        cek x = new cek();
        if (!"...".equals(admin.getTampTbhNIM().getText())) {
            Pelajar p = x.cariPelajar_nim(admin.getTampTbhNIM().getText());
            try{
                Database db = new Database();
                ResultSet rs = db.getData("select * from curriculum where idJurusan='"+p.getIdjurusan()+"';");
                while(rs.next()){
                    Matkul y = x.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    admin.getKeahlianTbhPengajar().addItem(rs.getString("idMatkul")+"   "+y.getNamaMatkul());
                }
                rs.close();
            } catch (Exception e){
                javax.swing.JOptionPane.showMessageDialog(null, "Error");
            }
        }
    }
    
    public static void main(String[] args) {
        new HandlerAdmin();   
        
    }
    
    
    
}
