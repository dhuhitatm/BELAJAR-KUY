/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;

/**
 *
 * @author Hilmi
 */
public class Mengajar {
    Pengajar pengajar;
    Matkul matkul;
    String idMengajar;
    
    public Mengajar(){}

    public Mengajar(Pengajar pengajar, Matkul matkul) {
        this.idMengajar = pengajar.getIdPengajar()+"-"+matkul.getIdMatkul();
        this.pengajar = pengajar;
        this.matkul = matkul;
    }
    
    public Pengajar getPengajar() {
        return pengajar;
    }

    public void setPengajar(Pengajar pengajar) {
        this.pengajar = pengajar;
    }

    public Matkul getMatkul() {
        return matkul;
    }

    public void setMatkul(Matkul matkul) {
        this.matkul = matkul;
    }

    public String getIdMengajar() {
        return idMengajar;
    }

    public void setIdMengajar(String idMengajar) {
        this.idMengajar = idMengajar;
    }
}
