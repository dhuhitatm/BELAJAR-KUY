/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class Pelajar {
    private String nama;
    private String nim;
    private String idjurusan;
    private int angkatan;
    private String username;
    private String password;
    private int jumJoin;

    public Pelajar() {
    }

    public Pelajar(String nama, String nim, String idjurusan, int angkatan, String username, String password, int jumJoin) {
        this.nama = nama;
        this.nim = nim;
        this.idjurusan = idjurusan;
        this.angkatan = angkatan;
        this.username = username;
        this.password = password;
        this.jumJoin = jumJoin;
    }
    
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getIdjurusan() {
        return idjurusan;
    }

    public void setIdjurusan(String idjurusan) {
        this.idjurusan = idjurusan;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getJumJoin() {
        return jumJoin;
    }

    public void setJumJoin(int jumJoin) {
        this.jumJoin = jumJoin;
    }
    
    
    
}
