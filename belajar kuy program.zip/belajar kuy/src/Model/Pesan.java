/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public class Pesan {
    private int idPesan;
    private String NimPengirim;
    private String NimPenerima;
    private String isiPesan;
    private static int idx = 0;
    
    public Pesan() {};

    public Pesan(String NimPengirim,String NimPenerima, String isiPesan) {
        this.idPesan = idx;
        this.NimPengirim = NimPengirim;
        this.NimPenerima = NimPenerima;
        this.isiPesan = isiPesan;
        idx = idx + 1;
    }

    public int getIdPesan() {
        return idPesan;
    }

    public void setIdPesan(int idPesan) {
        this.idPesan = idPesan;
    }

    public String getNimPengirim() {
        return NimPengirim;
    }

    public void setNimPengirim(String NimPengirim) {
        this.NimPengirim = NimPengirim;
    }

    public String getNimPenerima() {
        return NimPenerima;
    }

    public void setNimPenerima(String NimPenerima) {
        this.NimPenerima = NimPenerima;
    }

    public String getIsiPesan() {
        return isiPesan;
    }

    public void setIsiPesan(String isiPesan) {
        this.isiPesan = isiPesan;
    }

    public static int getIdx() {
        return idx;
    }

    public static void setIdx(int idx) {
        Pesan.idx = idx;
    }
    
    
}
