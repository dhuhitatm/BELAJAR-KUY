/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Hilmi
 */
public abstract class Kelas {
    private String namaKelas;
    private String idKelas;
    private String jam;
    private String tanggal;
    private int maxAnggota;
    private int jumAnggota;
    private Pelajar pembuat;
    private Curriculum curriculum;
    private String lokasi;
    private String deskripsiKelas;

    public Kelas() {}

    public Kelas(String namaKelas, String idKelas, String jam, String tanggal, int maxAnggota, int jumAnggota, Pelajar pembuat, Curriculum curriculum, String lokasi, String deskripsiKelas) {
        this.namaKelas = namaKelas;
        this.idKelas = idKelas;
        this.jam = jam;
        this.tanggal = tanggal;
        this.maxAnggota = maxAnggota;
        this.jumAnggota = jumAnggota;
        this.pembuat = pembuat;
        this.curriculum = curriculum;
        this.lokasi = lokasi;
        this.deskripsiKelas = deskripsiKelas;
    }

    public abstract void buatKelas();
    public abstract void hapusKelas();
    
    public abstract void joinKelas();
    public abstract void outKelas();
    
    
    public String getNamaKelas() {
        return namaKelas;
    }

    //get and set
    public void setNamaKelas(String namaKelas) {    
        this.namaKelas = namaKelas;
    }

    public String getIdKelas() {
        return idKelas;
    }

    public void setIdKelas(String idKelas) {
        this.idKelas = idKelas;
    }

    public String getJam() {
        return jam;
    }

    public void setJam(String jam) {
        this.jam = jam;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public int getMaxAnggota() {
        return maxAnggota;
    }

    public void setMaxAnggota(int maxAnggota) {
        this.maxAnggota = maxAnggota;
    }

    public int getJumAnggota() {
        return jumAnggota;
    }

    public void setJumAnggota(int x) {
        this.jumAnggota = x;
    }

    public Pelajar getPembuat() {
        return pembuat;
    }

    public void setPembuat(Pelajar pembuat) {
        this.pembuat = pembuat;
    }

    public Curriculum getCurriculum() {
        return curriculum;
    }

    public void setCurriculum(Curriculum curriculum) {
        this.curriculum = curriculum;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }    

    public String getDeskripsiKelas() {
        return deskripsiKelas;
    }

    public void setDeskripsiKelas(String deskripsiKelas) {
        this.deskripsiKelas = deskripsiKelas;
    }
    
    
}
