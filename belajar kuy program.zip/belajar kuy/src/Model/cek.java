/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * @author Hilmi
 */
public class cek {
    //Pelajar 
    public boolean cekAkunPelajar(String x, String y){ 
    //mengoutputkan TRUE jika terdapat username(x) dan password(y) pada table_pelajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT username, password FROM table_pelajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("username").equals(x)){
                    if(rs.getString("password").equals(y)){
                        cek=true;
                    }
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public boolean cekUsernamePelajar(String x){
        //mengoutputkan TRUE jika terdapat username(x) pada table_pelajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT username FROM table_pelajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("username").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Pelajar cariPelajar_nim(String x){
        //mengoutputkan Pelajar dengan NIM(x) pada table_pelajar
        Database db = new Database();
        String query1="SELECT * FROM table_pelajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("nim").equals(x)){
                    Pelajar h = new Pelajar();
                    h.setNim(rs.getString("nim"));
                    h.setNama(rs.getString("nama"));
                    h.setIdjurusan(rs.getString("idjurusan"));
                    h.setAngkatan(rs.getInt("angkatan"));
                    h.setUsername(rs.getString("username"));
                    h.setPassword(rs.getString("password"));
                    h.setJumJoin(rs.getInt("jumJoin"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public Pelajar cariPelajar_username(String x){
        //mengoutputkan Pelajar dengan NIM(x) pada table_pelajar
        Database db = new Database();
        String query1="SELECT * FROM table_pelajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("username").equals(x)){
                    Pelajar h = new Pelajar();
                    h.setNim(rs.getString("nim"));
                    h.setNama(rs.getString("nama"));
                    h.setIdjurusan(rs.getString("idjurusan"));
                    h.setAngkatan(rs.getInt("angkatan"));
                    h.setUsername(rs.getString("username"));
                    h.setPassword(rs.getString("password"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public boolean cekNimPelajar(String x){
        //mengoutputkan TRUE jika terdapat NIM(x) pada table_pelajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT nim FROM table_pelajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("nim").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Pelajar cariPelajar_idPengajar(String x){
        Database db = new Database();
        String query1="SELECT * FROM table_pengajar join table_pelajar using(nim) where idPengajar='"+x+"';";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idPengajar").equals(x)){
                    Pelajar h = new Pelajar();
                    h.setNim(rs.getString("nim"));
                    h.setNama(rs.getString("nama"));
                    h.setIdjurusan(rs.getString("idjurusan"));
                    h.setAngkatan(rs.getInt("angkatan"));
                    h.setUsername(rs.getString("username"));
                    h.setPassword(rs.getString("password"));
                    return h;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public Pengajar cariPengjar_idPengajar(String x){
        Database db = new Database();
        String query1="SELECT * FROM table_pengajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idPengajar").equals(x)){
                    Pengajar h = new Pengajar();
                    h.setIdPengajar(rs.getString("idPengajar"));
                    h.setJumlahKeahlian(rs.getInt("jumlahKeahlian"));
                    return h;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public String cariPengajar_nim(String x){
        //mengoutputkan Pelajar dengan NIM(x) pada table_pelajar
        Database db = new Database();
        String query1="SELECT * FROM table_pengajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("nim").equals(x)){
                   String h = rs.getString("idPengajar");
                    
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    
    //Pengajar
    public boolean cekNimPengajar(String x){ 
    //mengoutputkan TRUE jika terdapat NIM(x) pada table_pengajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT nim FROM table_pengajar;";
        ResultSet rs = db.getData(query1);
        
        try{
            while(rs.next()){
                if(rs.getString("nim").equals(x)){
                    cek = true;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public boolean cekidPengajar(String x, Matkul c) {
        boolean cek =false;
        Database db = new Database();
        ResultSet rs = null;
         rs = db.getData("select idPengajar, jadwal, nama from mengajar join jadwal_pengajar using (idPengajar) join table_pengajar using (idPengajar) join table_pelajar using (nim) where idMatkul='"+c.getIdMatkul()+"';");
        
        try{
            while(rs.next()){
                if(x.equals(rs.getString("idPengajar"))){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }

    
    //Jurusan
    public boolean cekidJurusan(String x){
        //mengoutputkan TRUE jika terdapat idJurusan(x) pada table_jurusan
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idJurusan FROM table_jurusan;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idJurusan").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Jurusan cariJurusan_idJurusan(String x){
        //mengoutputkan Jurusan dengan idJurusan(x) pada table_Jurusan
        Database db = new Database();
        String query1="SELECT * FROM table_jurusan;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idJurusan").equals(x)){
                    Jurusan h = new Jurusan();
                    h.setIdJurusan(rs.getString("idJurusan"));
                    h.setNamaJurusan(rs.getString("namaJurusan"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public Jurusan cariJurusan_namaJurusan(String x){
        //mengoutputkan Jurusan dengan namaJurusan(x) pada table_Jurusan
        Database db = new Database();
        String query1="SELECT * FROM table_jurusan;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("namaJurusan").equals(x)){
                    Jurusan h = new Jurusan();
                    h.setIdJurusan(rs.getString("idJurusan"));
                    h.setNamaJurusan(rs.getString("namaJurusan"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    

// Matkul
    
    public boolean cekidMatkul(String x){
        //mengoutputkan TRUE jika terdapat idMatkul(x) pada table_Matkul
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idMatkul FROM table_matakuliah;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idMatkul").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Matkul cariMatkul_idMatkul(String x){
        //mengoutputkan Jurusan dengan idJurusan(x) pada table_Jurusan
        Database db = new Database();
        String query1="SELECT * FROM table_matakuliah;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idMatkul").equals(x)){
                    Matkul h = new Matkul();
                    h.setIdMatkul(rs.getString("idMatkul"));
                    h.setNamaMatkul(rs.getString("namaMatkul"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public Matkul cariMatkul_namaMatkul(String x){
        //mengoutputkan Jurusan dengan idJurusan(x) pada table_Jurusan
        Database db = new Database();
        String query1="SELECT * FROM table_matakuliah;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("namaMatkul").equals(x)){
                    Matkul h = new Matkul();
                    h.setIdMatkul(rs.getString("idMatkul"));
                    h.setNamaMatkul(rs.getString("namaMatkul"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
//Curriculum
    
    public boolean cekidCurriculum(String x){
        //mengoutputkan TRUE jika terdapat idCurriculum(x) pada table curriculum
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idCurriculum FROM curriculum;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idCurriculum").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Curriculum cariCurriculum_idCurriculum(String x){
        //mengoutputkan Curriculum dengan idCurriculum(x) pada table curriculum
        Database db = new Database();
        String query1="SELECT * FROM curriculum;";
        ResultSet rs = db.getData(query1);
        cek k = new cek();
        try{
            while(rs.next()){
                if(rs.getString("idCurriculum").equals(x)){
                    Curriculum h = new Curriculum();
                    h.setIdCurriculum(rs.getString("idCurriculum"));
                    Jurusan a = k.cariJurusan_idJurusan(rs.getString("idJurusan"));
                    h.setJurusan(a);
                    Matkul b = k.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    h.setMatkul(b);
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    //mengajar
    public boolean cekidMengajar(String x){
        //mengoutputkan TRUE jika terdapat idMengajar(x) pada table mengajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idMengajar FROM mengajar;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idMengajar").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public Mengajar cariMengajar_idMengajar(String x){
        Database db = new Database();
        String query1="SELECT * FROM mengajar;";
        ResultSet rs = db.getData(query1);
        cek k = new cek();
        try{
            while(rs.next()){
                if(rs.getString("idMengajar").equals(x)){
                    Mengajar h = new Mengajar();
                    h.setIdMengajar(rs.getString("idMengajar"));
                    Pengajar a = k.cariPengjar_idPengajar(rs.getString("idPengajar"));
                    h.setPengajar(a);
                    Matkul b = k.cariMatkul_idMatkul(rs.getString("idMatkul"));
                    h.setMatkul(b);
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    //Kelas_withoutMentor
    public boolean cekidKelasNomentor(String x){
        //mengoutputkan TRUE jika terdapat idKelas(x) pada table kelas_nomentor
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idKelas FROM kelas_nomentor;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idKelas").equals(x)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    public withoutMentor cariKelas_idKelasNomentor(String x){
        Database db = new Database();
        String query1="SELECT * FROM kelas_nomentor;";
        ResultSet rs = db.getData(query1);
        cek k = new cek();
        try{
            while(rs.next()){
                if(rs.getString("idKelas").equals(x)){
                    withoutMentor h = new withoutMentor();
                    h.setIdKelas(rs.getString("idKelas"));
                    h.setNamaKelas(rs.getString("namaKelas"));
                    h.setTanggal(rs.getString("tanggal"));
                    h.setJam(rs.getString("tanggal"));
                    h.setMaxAnggota(rs.getInt("maxAnggota"));
                    h.setJumAnggota(rs.getInt("jumAnggota"));
                    Pelajar p = k.cariPelajar_nim(rs.getString("nim"));
                    h.setPembuat(p);
                    Curriculum c = k.cariCurriculum_idCurriculum(rs.getString("idcurriculum"));
                    h.setCurriculum(c);
                    h.setLokasi(rs.getString("lokasi"));
                    h.setDeskripsiKelas(rs.getString("deskripsiKelas"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    
    
    //kelas_withmentor
    public withMentor cariKelas_idKelasWithmentor(String x){
        Database db = new Database();
        String query1="SELECT * FROM kelas_withmentor;";
        ResultSet rs = db.getData(query1);
        cek k = new cek();
        try{
            while(rs.next()){
                if(rs.getString("idKelas").equals(x)){
                    withMentor h = new withMentor();
                    h.setIdKelas(rs.getString("idKelas"));
                    h.setNamaKelas(rs.getString("namaKelas"));
                    h.setTanggal(rs.getString("tanggal"));
                    h.setJam(rs.getString("tanggal"));
                    h.setMaxAnggota(rs.getInt("maxAnggota"));
                    h.setJumAnggota(rs.getInt("jumAnggota"));
                    Pelajar p = k.cariPelajar_nim(rs.getString("nim"));
                    h.setPembuat(p);
                    Curriculum c = k.cariCurriculum_idCurriculum(rs.getString("idcurriculum"));
                    h.setCurriculum(c);
                    h.setLokasi(rs.getString("lokasi"));
                    h.setDeskripsiKelas(rs.getString("deskripsiKelas"));
                    h.setMateri(rs.getString("materi"));
                    h.setSoal(rs.getString("soal"));
                    h.setIdPengajar(rs.getString("idPengajar"));
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public boolean cekkelasWithmentor_idpengajar_tangal(String x, String y){
        // mengoutputkan true jukaterdapat id pengajar(x) dan tanggal(y) pada table jadwalPengajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT * FROM kelas_withmentor where idPengajar='"+x+"' and tanggal ='"+y+"';";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idPengajar").equals(x) && rs.getString("tanggal").equals(y)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    
    //Pesan
    public int cekidxPesan(){
        Database db = new Database();
        String query1="SELECT idPesan FROM pesan;";
        ResultSet rs = db.getData(query1);
        int x = 0;
        try{
            while(rs.next()){
                x = (rs.getInt("idPesan"));
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return x;
    }
    
     public boolean cekidPesan(int x) {
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT idPesan FROM pesan;";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(x == rs.getInt("idPesan")){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
     }
     
     public Pesan cariPesan_idPesan(int x){
        //mengoutputkan Pelajar dengan NIM(x) pada table_pelajar
        Database db = new Database();
        String query1="SELECT * FROM pesan;";
        ResultSet rs = db.getData(query1);
        
        try{
            while(rs.next()){
                if(x == rs.getInt("idPesan")){
                    Pesan h = new Pesan();
                    h.setNimPenerima(rs.getString("NimPenerima"));
                    h.setNimPengirim(rs.getString("NimPengirim"));
                    h.setIsiPesan(rs.getString("isiPesan"));
                  
                    return h;
                }
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
     
    //JadwalPengajar
    public jadwalPengajar carijadwalPengajar_idPengajar_tanggal(String x, String y){
        Database db = new Database();
        String query1="SELECT * FROM jadwal_pengajar where idPengajar='"+x+"' and jadwal ='"+y+"';";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                jadwalPengajar h = new jadwalPengajar();
                h.setIdJadwal(rs.getString("idJadwal"));
                h.setJadwal(rs.getString("jadwal"));
                h.setIdPengajar(rs.getString("idPengajar"));
                return h;
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return null;
    }
    
    public boolean cekjadwalPengajar_idpengajar_tangal(String x, String y){
        // mengoutputkan true jukaterdapat id pengajar(x) dan tanggal(y) pada table jadwalPengajar
        boolean cek =false;
        Database db = new Database();
        String query1="SELECT * FROM jadwal_pengajar where idPengajar='"+x+"' and jadwal ='"+y+"';";
        ResultSet rs = db.getData(query1);
        try{
            while(rs.next()){
                if(rs.getString("idPengajar").equals(x) && rs.getString("jadwal").equals(y)){
                    cek = true;
                } 
            }
            rs.close();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),"Gagal Query",JOptionPane.WARNING_MESSAGE);
        }
        return cek;
    }
    
    
    //other
    public int randomNumberGenerator(){
        Random r = new Random();
        int Max = 3000;
        int Min = 0;
        return (r.nextInt((Max - Min) + 1) + Min);
    }
    
    public String splitText(String x){
        String arr[] = x.split(" ",2);
        return arr[0];
    }

    public boolean cekKabisat(int x){
        if ((x%4)!=0) {
            return false;
        } else if ((x%100)==0 && (x%400)!=0) {
            return false;
        } else {
            return true;
        }
    }
    
    public String cekNamaBulan(int i){
        String y = "";
        for (int x = i; x <= 12; x++) {
            if(i==1){
                y="Januari";
            }
            if (i==2) {
                y="Februari";
            }
            if(i==3){
                y="Maret";
            }
            if (i==4) {
                y="April";
            }
            if(i==5){
                y="Mei";
            }
            if (i==6) {
                y="Juni";
            }
            if(i==7){
                y="Juli";
            }
            if (i==8) {
                y="Agustus";
            }
            if(i==9){
                y="September";
            }
            if (i==10) {
                y="Oktober";
            }
            if(i==11){
                y="November";
            }
            if (i==12) {
                y=("Desember");
            }
        }
        return y;
    }
    
    public String cekNomorBulan(String i){
        String y = "";
        for (int x = 1; x <= 12; x++) {
            if("Januari".equals(i)){
                y="01";
            }
            if ("Februari".equals(i)) {
                y="02";
            }
            if("Maret".equals(i)){
                y="03";
            }
            if ("April".equals(i)) {
                y="04";
            }
            if("Mei".equals(i)){
                y="05";
            }
            if ("Juni".equals(i)) {
                y="06";
            }
            if("Juli".equals(i)){
                y="07";
            }
            if ("Agustus".equals(i)) {
                y="08";
            }
            if("September".equals(i)){
                y="09";
            }
            if ("Oktober".equals(i)) {
                y="10";
            }
            if("November".equals(i)){
                y="11";
            }
            if ("Desember".equals(i)) {
                y=("12");
            }
        }
        return y;
    }
}
